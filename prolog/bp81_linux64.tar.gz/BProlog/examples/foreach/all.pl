:-cl(array),go.
%:-cl(assign),go.
:-cl(bqueens),go.
:-cl(ex1),go.
:-cl(length_sum),go.
:-cl(magic),go.
:-cl(perms),go.
:-cl(qsort),go.
:-cl(queens),go.
:-cl(staircase),go.

