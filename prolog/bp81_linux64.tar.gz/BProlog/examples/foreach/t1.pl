go(X,I,Y):-
    X[I] @= Y.
